import { LightningElement, api, track, wire } from 'lwc';
import getCandidatesList from '@salesforce/apex/CandidatesForPositionHelper.getCandidatesList';
import getCandidateForModal from '@salesforce/apex/CandidatesForPositionHelper.getCandidateForModal';
import getFieldSetForm from '@salesforce/apex/CandidatesForPositionHelper.getFieldSetForm';

export default class RelatedJobApplications2Candidate extends LightningElement {

    @api recordId;
    @api candidateId;
    @api jaObjectApiName = 'Job_Application__c';
    @api jobAppFieldSet = 'JAFieldSet';
    jaFieldSet = [];

    getJobAppInfo() {
        getFieldSetForm({objectName:this.jaObjectApiName, fieldSetName:this.jobAppFieldSet})
        .then(result => {
            console.log('JA result:'+ JSON.stringify(result));
            this.jaFieldSet = result;
            for(let key in result) {
                if (result.hasOwnProperty(key)) { 
                    this.jaFieldSet.push({value:result[key], key:key});
                }
            }
        }) 
        .catch(error => {
            console.log('error:'+ error);
            this.error = error;
        });
    }
    
}