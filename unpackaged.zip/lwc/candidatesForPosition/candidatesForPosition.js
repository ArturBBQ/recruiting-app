import { LightningElement } from 'lwc';

export default class CandidatesForPosition extends LightningElement {}