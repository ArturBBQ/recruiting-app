import { LightningElement, wire, api } from 'lwc';

import getPositionList from '@salesforce/apex/PositionHelper2nd.getPositionList';
import { getPicklistValues, getObjectInfo } from 'lightning/uiObjectInfoApi';
import POSITION_OBJECT from '@salesforce/schema/Position__c';
import STATUS_FIELD from '@salesforce/schema/Position__c.Status__c';

export default class PositonLWC_2nd extends LightningElement {

records;
error;
visibleRecords;
positionStatusValues;
startIndex;
endIndex;

@wire( getObjectInfo, { objectApiName: POSITION_OBJECT } )
    objectInfo;

    connectedCallback() {
        getPositionList()
        .then(result => {
            this.records = result;
          })
        .catch(error => {
            this.error = error;
        });
      } 
    
      @wire( getPicklistValues, { recordTypeId: "$objectInfo.data.defaultRecordTypeId", fieldApiName: STATUS_FIELD } )
    getStatePicklistValues({data, error}) {
      if (data) {
        this.positionStatusValues = data.values;
      } else if (error) {
        this.error = error;
    }
  }
}