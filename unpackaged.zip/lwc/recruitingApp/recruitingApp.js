import { LightningElement } from 'lwc';

export default class RecruitingApp extends LightningElement {

}