import { LightningElement } from 'lwc';

export default class positionLWC extends LightningElement {

}