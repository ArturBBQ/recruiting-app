import { LightningElement, api } from 'lwc';
import getFieldSetForm from '@salesforce/apex/CandidatesForPositionHelper.getFieldSetForm';
import getCandidateForModal from '@salesforce/apex/CandidatesForPositionHelper.getCandidateForModal';
import { NavigationMixin } from 'lightning/navigation';

export default class CandidateModalWindow extends NavigationMixin(LightningElement) {

    @api candidateId;
    @api candidateObjectApiName = 'Candidate__c';
    @api candidateLongFieldSet = 'Candidate_info_long';
    longCandidateFieldSet = [];
    error;
    ShowModal = false;
    
   @api 
   openCandidateDetail(event) {
        console.log('CHILD START');

        console.log('CHILD event (id)' + event);
        //this.candidateId = event;
        //this.getLongCandidateInfo();
    }
    
    closeModal() {
        this.ShowModal = false;
    }

    getLongCandidateInfo() {
        getFieldSetForm({objectName:this.candidateObjectApiName, fieldSetName:this.candidateLongFieldSet})
        .then(result => {
            console.log('longCandidateFieldSet:'+ JSON.stringify(result));
            this.longCandidateFieldSet = result;
            for(let key in result) {
                if (result.hasOwnProperty(key)) { 
                    this.longCandidateFieldSet.push({value:result[key], key:key});
                }
            }
        }) 
        .catch(error => {
            this.error = error;
        });
    }

    candidateForModal() {
        getCandidateForModal({candidateId: this.candidateId})
        .then(result => {
            console.log('getCandidateForModal this.candidate:'+ JSON.stringify(result));
            this.candidate = result;
        })
        .catch(error => {
            this.error = error;
            console.log('error:', error);
        });
    }

    navigateToCandidatePage(event) {
        this.candidateId = event.currentTarget.dataset.id;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.candidateId,
                objectApiName: 'Candidate__c',
                actionName: 'view'
            }
        });
    }

}